import uuid

from WS.models.city import CityCreateDto


def generate_unique_city_name(prefix="smoke-city"):
    return f"{prefix}-{uuid.uuid4().hex[:8]}"

def create_city_payload(name: str):

    return CityCreateDto(name=name).model_dump()

def assert_city_response(resp, expected_name):

    assert resp.status_code == 200 or resp.status_code == 201, \
        f"Ожидался статус 200/201, но получен {resp.status_code}: {resp.text}"
    data = resp.json()
    assert data["name"] == expected_name, f"Ожидаемое имя '{expected_name}', но получили '{data['name']}'"
    return data

def generate_update_payload(new_name=None):

    if not new_name:
        new_name = generate_unique_city_name()
    return {"name": new_name}, new_name

def update_city(api, city_id, new_name=None):
    payload, name = generate_update_payload(new_name)
    resp = api.update(city_id, payload)
    return resp, name