import uuid

from WS.models.dealer import DealerCreateDto


def generate_unique_dealer_name(prefix="dealer"):
    return f"{prefix}-{uuid.uuid4().hex[:8]}"

def create_dealer_payload(name: str):

    return DealerCreateDto(name=name).model_dump()

def assert_dealer_response(resp, expected_name):

    assert resp.status_code == 200 or resp.status_code == 201, \
        f"Ожидался статус 200/201, но получен {resp.status_code}: {resp.text}"
    data = resp.json()
    assert data["name"] == expected_name, f"Ожидаемое имя '{expected_name}', но получили '{data['name']}'"
    return data

def generate_update_payload(new_name=None):

    if not new_name:
        new_name = generate_unique_dealer_name()
    return {"name": new_name}, new_name

def update_dealer(api, dealer_id, new_name=None):
    payload, name = generate_update_payload(new_name)
    resp = api.update(dealer_id, payload)
    return resp, name
