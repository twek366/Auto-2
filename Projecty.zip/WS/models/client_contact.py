from typing import Optional

from pydantic import BaseModel, EmailStr


class ClientContactEditDto(BaseModel):
    name: Optional[str] = None
    client: Optional[int] = None
    comment: Optional[str] = None
    guide: Optional[bool] = None
    position: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None

class ClientContactReadDto(BaseModel):
    id: int
    client: int
    name: str
    comment: Optional[str] = None
    position: Optional[str] = None
    guide: bool
    phone: Optional[str] = None
    email: Optional[EmailStr] = None

class ClientContactCreateDto(BaseModel):
    name: str
    client: int
    comment: Optional[str] = None
    guide: bool
    position: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None