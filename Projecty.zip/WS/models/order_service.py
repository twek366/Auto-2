from typing import Optional

from pydantic import BaseModel, Field


class OrderServiceEditDto(BaseModel):
    order: int
    addService: int
    m3: int = Field(..., ge=1, le=2)
    sum: Optional[int] = None

class OrderServiceReadDto(BaseModel):
    id: int
    order: int
    addService: int
    m3: int
    sum: int

class OrderServiceCreateDto(BaseModel):
    order: int
    addService: int
    m3: Optional[int] = Field(None, ge=1, le=2)
    sum: Optional[int] = None