from typing import Optional

from pydantic import BaseModel


class DealerEditDto(BaseModel):
    name: Optional[str] = None

class DealerCreateDto(BaseModel):
    name: str