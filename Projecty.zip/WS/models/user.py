from typing import List, Literal, Optional

from pydantic import BaseModel, EmailStr, Field

RoleEnum = Literal["OWNER", "ADMINISTRATOR", "MANAGER", "CLIENT_USER", "UNKNOWN"]

class UserSettingDto(BaseModel):
    id: int
    value: bool

class UserSettingDetailsDto(BaseModel):
    id: int
    name: str
    setting_sort: int
    value: bool

class UserGroupDto(BaseModel):
    group_id: int
    group_name: str
    in_group: bool
    settings: List[UserSettingDetailsDto]

class UserEditDto(BaseModel):
    username: Optional[str] = Field(None, pattern=r"^[a-zA-Z0-9_]+$")
    email: Optional[EmailStr] = None
    password: Optional[str] = Field(None, min_length=8, max_length=128)
    firstName: Optional[str] = Field(None, min_length=1, max_length=32)
    lastName: Optional[str] = Field(None, min_length=1, max_length=32)
    defaultCity: Optional[int] = None
    language: Optional[int] = None
    role: Optional[str] = None
    clientId: Optional[int] = None
    dealer: Optional[int] = None
    active: Optional[bool] = None

class UserReadDto(BaseModel):
    id: int
    username: str
    email: str
    lastName: str
    firstName: str
    role: RoleEnum
    avatar: Optional[str] = None
    clientId: Optional[int] = None
    defaultLanguage: Optional[int] = None
    defaultCity: Optional[int] = None
    dealer: Optional[int] = None
    active: bool

class UserRegisterDto(BaseModel):
    username: str = Field(..., pattern=r"^[a-zA-Z0-9_]+$")
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    firstName: str = Field(..., min_length=1, max_length=32)
    lastName: str = Field(..., min_length=1, max_length=32)
    defaultCity: int
    language: Optional[int] = None
    role: str
    client: Optional[int] = None