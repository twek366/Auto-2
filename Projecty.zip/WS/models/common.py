from datetime import datetime

from pydantic import BaseModel


class Point(BaseModel):
    lat: float
    lon: float

class City(BaseModel):
    id: int
    name: str

class CityReadDto(City):
    pass

class Courier(BaseModel):
    id: int
    name: str

class Guide(BaseModel):
    id: int
    name: str
    phone: str

class DealerReadDto(BaseModel):
    id: int
    name: str

class ClientOrderListElementDto(BaseModel):
    id: int
    name: str

class Metadata(BaseModel):
    page: int
    size: int
    totalElements: int

class ErrorResponse(BaseModel):
    date: datetime
    message: dict