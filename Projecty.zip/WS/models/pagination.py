from typing import Generic, List, TypeVar

from pydantic import BaseModel

from .client import ClientReadDto
from .common import Metadata
from .order import OrderListElement

T = TypeVar("T")

class PageResponse(BaseModel, Generic[T]):
    content: List[T]
    metadata: Metadata

PageResponseOrderListElement = PageResponse[OrderListElement]
PageResponseClientReadDto = PageResponse[ClientReadDto]