from typing import List, Optional

from pydantic import BaseModel


class GroupsReportDeviceDetails(BaseModel):
    id: str
    startHour: Optional[int] = None
    endHour: Optional[int] = None
    work: Optional[int] = None

class DeviceGroupReport(BaseModel):
    orderId: int
    rx: int
    tx: int
    delivered: bool
    returned: bool
    status: int
    start: str  # date-time
    end: str    # date-time
    totalHours: int

class DeviceGroupDetailsReport(BaseModel):
    orderId: int
    rx: int
    tx: int
    delivered: bool
    returned: bool
    status: int
    start: str
    end: str
    totalHours: int
    deviceResult: List[GroupsReportDeviceDetails]