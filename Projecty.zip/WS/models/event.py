from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel

from .common import City, Courier, Guide, Point
from .order_comment import OrderCommentReadDto


class DeviceStateRequestDto(BaseModel):
    id: str
    days_left: Optional[int] = None
    days_store: Optional[int] = None
    stat_hours_work: Optional[int] = None
    stat_excur: Optional[int] = None
    stat_sync: Optional[int] = None
    stat_charge: Optional[int] = None
    errors: Optional[int] = None
    acb_max_hours: Optional[int] = None
    acb_work_hours: Optional[int] = None
    tx_flag: Optional[bool] = None
    firm: Optional[int] = None
    hardware: Optional[int] = None
    software: Optional[int] = None
    vbat: Optional[int] = None
    adr_num: Optional[int] = None
    chnl: Optional[int] = None
    rssi: Optional[int] = None

class EventRegisterDto(BaseModel):
    location: Point
    appId: str
    foundDevices: List[DeviceStateRequestDto] = []
    pickedDevices: List[DeviceStateRequestDto] = []
    order: int
    addComment: Optional[str] = None

class EventEditDto(BaseModel):
    returnPlace: Optional[str] = None
    returnTime: Optional[datetime] = None
    transmitters: Optional[int] = None
    receivers: Optional[int] = None
    extraReceivers: Optional[int] = None
    returnUser: Optional[int] = None
    deliveryUser: Optional[int] = None
    addComment: Optional[str] = None

class EventReadDto(BaseModel):
    id: int
    rx: int
    tx: int
    delivery: bool
    dateTime: datetime
    returnTime: Optional[datetime] = None
    deliveryPlace: str
    returnPlace: str
    comments: List[OrderCommentReadDto] = []
    courier: Courier
    clientName: str
    city: City
    delivered: bool
    returned: bool
    closed: bool
    paid: bool
    manualDocId: Optional[str] = None
    guide: Guide
    extraReceivers: int
    status: int