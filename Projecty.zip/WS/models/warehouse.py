from typing import Optional

from pydantic import BaseModel


class WarehouseEditDto(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    city: Optional[int] = None

class WarehouseReadDto(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    city: int

class WarehouseCreateDto(BaseModel):
    name: str
    description: Optional[str] = None
    city: Optional[int] = None