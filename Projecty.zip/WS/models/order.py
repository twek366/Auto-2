from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from ..models.common import ClientOrderListElementDto


class OrderEditDto(BaseModel):
    rentDays: Optional[int] = None
    receivers: Optional[int] = None
    transmitters: Optional[int] = None
    deliveryTime: Optional[datetime] = None
    returnTime: Optional[datetime] = None
    deliveryPlace: Optional[str] = None
    returnPlace: Optional[str] = None
    deliveryUser: Optional[int] = None
    returnUser: Optional[int] = None
    client: Optional[int] = None
    canceled: Optional[bool] = None
    returnCity: Optional[int] = None
    city: Optional[int] = None
    delivered: Optional[bool] = None
    returned: Optional[bool] = None
    closed: Optional[bool] = None
    paid: Optional[bool] = None
    manualDocId: Optional[str] = None
    deleted: Optional[bool] = None
    guide: Optional[int] = None
    manager: Optional[int] = None
    extraReceivers: Optional[int] = None
    extraTransm: Optional[int] = None
    tariffPrice: Optional[int] = None
    currency: Optional[int] = None
    contract: Optional[int] = None
    factReceivers: Optional[int] = None
    factDays: Optional[int] = None
    sum: Optional[float] = None
    sumIsFixed: Optional[bool] = None
    confirmed: Optional[bool] = None

class OrderReadDto(BaseModel):
    id: int
    createdAt: datetime
    creator: int
    updatedAt: datetime
    lastUpdateUser: int
    rentDays: Optional[int] = None
    receivers: int
    transmitters: int
    deliveryTime: datetime
    returnTime: datetime
    deliveryPlace: str
    returnPlace: str
    deliveryUser: Optional[int] = None
    returnUser: Optional[int] = None
    client: int
    canceled: bool
    returnCity: Optional[int] = None
    delivered: bool
    returned: bool
    closed: bool
    paid: bool
    manualDocId: Optional[str] = None
    deleted: bool
    guide: Optional[int] = None
    manager: Optional[int] = None
    extraReceivers: Optional[int] = None
    extraTransm: Optional[int] = None
    status: int
    cancelDate: Optional[datetime] = None
    tariffPrice: Optional[int] = None
    currency: Optional[int] = None
    contract: Optional[int] = None
    factReceivers: Optional[int] = None
    factDays: Optional[int] = None
    sum: Optional[float] = None
    sumIsFixed: Optional[bool] = None
    confirmed: Optional[bool] = None

class OrderCreateDto(BaseModel):
    receivers: int
    transmitters: int
    deliveryTime: datetime
    returnTime: datetime
    deliveryPlace: str
    returnPlace: str
    deliveryUser: Optional[int] = None
    returnUser: Optional[int] = None
    client: int
    returnCity: int
    city: int
    manualDocId: Optional[str] = None
    guide: int
    manager: Optional[int] = None
    extraReceivers: Optional[int] = None
    extraTransm: Optional[int] = None
    tariffPrice: Optional[int] = None
    currency: Optional[int] = None
    contract: int
    factReceivers: Optional[int] = None
    factDays: Optional[int] = None
    sum: Optional[float] = None
    sumIsFixed: Optional[bool] = None
    status: Optional[int] = Field(None, ge=1, le=12)

class OrderListElement(BaseModel):
    id: int
    date: datetime
    client: ClientOrderListElementDto
    receivers: int
    transmitters: int
    sum: Optional[float] = None
    deliverTime: datetime
    returnTime: datetime
    deliveryPlace: str
    returnPlace: str
    canceled: bool
    delivered: bool
    returned: bool
    manualDocId: Optional[str] = None
    status: int