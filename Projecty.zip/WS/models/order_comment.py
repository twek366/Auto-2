from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class OrderCommentReadDto(BaseModel):
    id: int
    hidden: bool
    text: str
    order: int
    author: str
    createdAt: datetime

class OrderCommentCreateDto(BaseModel):
    hidden: Optional[bool] = None
    text: str