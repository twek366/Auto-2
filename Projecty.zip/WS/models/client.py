from typing import Optional

from pydantic import BaseModel


class ClientEditDto(BaseModel):
    name: Optional[str] = None
    city: Optional[int] = None
    description: Optional[str] = None
    tpi: Optional[str] = None

class ClientReadDto(BaseModel):
    id: int
    name: str
    city: Optional[int] = None
    description: Optional[str] = None
    tpi: Optional[str] = None

class ClientCreateDto(BaseModel):
    name: str
    city: Optional[int] = None
    description: Optional[str] = None
    tpi: Optional[str] = None