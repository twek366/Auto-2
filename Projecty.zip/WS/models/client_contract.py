from datetime import date
from typing import Optional

from pydantic import BaseModel, Field


class ClientContractEditDto(BaseModel):
    client: Optional[int] = None
    contactNum: Optional[str] = None
    startDate: Optional[date] = None
    endDate: Optional[date] = None
    defaultTariff: Optional[int] = Field(None, ge=1, le=3)
    currency: Optional[int] = None
    tariffHour: Optional[float] = None
    tariffDay: Optional[float] = None
    tariffTour: Optional[float] = None
    isDefault: Optional[bool] = None
    r3: Optional[bool] = None

class ClientContractReadDto(BaseModel):
    id: int
    client: int
    createdAt: date
    startDate: date
    endDate: date
    defaultTariff: int
    currency: int
    tariffHour: Optional[float] = None
    tariffDay: Optional[float] = None
    tariffTour: Optional[float] = None
    isDefault: bool
    r3: bool

class ClientContractCreateDto(BaseModel):
    client: int
    contactNum: Optional[str] = None
    startDate: Optional[date] = None
    endDate: Optional[date] = None
    defaultTariff: int = Field(..., ge=1, le=3)
    currency: int
    tariffHour: Optional[float] = None
    tariffDay: Optional[float] = None
    tariffTour: Optional[float] = None
    isDefault: Optional[bool] = None
    r3: Optional[bool] = None