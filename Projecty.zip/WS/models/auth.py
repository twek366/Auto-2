from typing import List, Optional

from pydantic import BaseModel

from .common import CityReadDto, DealerReadDto
from .user import RoleEnum, UserSettingDto


class UserLoginDto(BaseModel):
    login: str
    password: str

class UserAuthDto(BaseModel):
    id: int
    username: str
    email: str
    firstName: str
    lastName: str
    dealer: Optional[str] = None
    dealerId: Optional[int] = None
    avatar: Optional[str] = None
    clientId: Optional[int] = None
    defaultLanguage: Optional[int] = None
    defaultCity: Optional[int] = None
    token: str

class CurrentUserDto(BaseModel):
    id: int
    dealer: Optional[DealerReadDto] = None
    userSettings: List[UserSettingDto] = []
    userGroups: List[int] = []
    username: str
    email: str
    firstName: str
    lastName: str
    defaultCity: Optional[CityReadDto] = None
    language: Optional[int] = None
    avatar: Optional[str] = None
    role: RoleEnum
    clientId: Optional[int] = None
    token: str