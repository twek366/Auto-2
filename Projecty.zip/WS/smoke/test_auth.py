import pytest

from WS.api.auth_api import AuthApi
from WS.config.settings import login_owner, pass_owner
from WS.logging_config import logger


@pytest.mark.smoke
def test_refresh_token(admin_token):
    """Тест обновления токена.
     Использует фикстуру admin_token для получения начального токена."""

    logger.info("Начало теста обновления токена")
    logger.debug(f"Получен токен из фикстуры (первые 20 символов): {admin_token[:20] if admin_token else 'None'}...")

    # Создаем экземпляр AuthApi с токеном из фикстуры
    api = AuthApi(token=admin_token)
    logger.debug("Создан экземпляр AuthApi с токеном")

    # Отправляем запрос на обновление токена
    logger.info("Отправка запроса на обновление токена...")
    resp = api.refresh()
    logger.debug(f"Получен ответ со статусом: {resp.status_code}")

    # Проверяем статус код
    assert resp.status_code == 200, f"Ожидался статус 200, получен {resp.status_code}. Ответ: {resp.text}"
    logger.info("✅ Статус код 200 подтвержден")

    # Проверяем структуру ответа
    data = resp.json()
    logger.debug(f"Получены данные ответа: {data}")

    assert "token" in data, f"Ответ не содержит ключ 'token'. Ответ: {data}"
    logger.info("✅ Ключ 'token' присутствует в ответе")

    assert data.get("token") is not None, "Токен в ответе равен None"
    logger.info("✅ Токен в ответе не пустой")

    # Дополнительная проверка: новый токен не должен быть равен старому
    new_token = data.get("token")
    # if admin_token and new_token:
    #    assert new_token != admin_token, "Новый токен должен отличаться от старого"
    #    logger.info("✅ Новый токен отличается от старого")
    #    else:
    #     logger.warning("Не удалось сравнить токены (один из них None)")

    logger.info("✅ Тест обновления токена успешно завершен")
    logger.debug(f"Новый токен (первые 20 символов): {new_token[:20] if new_token else 'None'}...")

@pytest.mark.smoke
def test_login_success():
    api = AuthApi()
    resp = api.login(login=login_owner, password=pass_owner)
    assert resp.status_code == 200
    data = resp.json()
    assert "token" in data or data.get("token") is not None
