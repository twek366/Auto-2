import pytest

from WS.helpers.users import assert_user_get_response, update_user
from WS.logging_config import logger


@pytest.mark.smoke
def test_create_user(user):
    logger.info(f"Тест создания пользователя прошёл успешно: {user['username']}")

@pytest.mark.smoke
def test_get_user(user):
    get_resp = user["api"].get_by_id(user["id"])
    assert_user_get_response(get_resp, user["username"])
    logger.info(f"Тест получения пользователя прошёл успешно: {user['username']}")

@pytest.mark.smoke
def test_update_user(user):
    resp, updated_values = update_user(user["api"], user["id"])
    assert resp.status_code == 200
    dto = assert_user_get_response(resp)
    for key, val in updated_values.items():
        assert getattr(dto, key) == val
    logger.info(
        f"Пользователь {user['username']} ({user['id']}) успешно обновлён"
    )

@pytest.mark.smoke
def test_delete_user(user):
    delete_resp = user["api"].delete_by_id(user["id"])
    assert delete_resp.status_code == 204, f"Не удалось удалить пользователя {user['username']}: {delete_resp.status_code}"

    get_after_delete = user["api"].get_by_id(user["id"])
    assert get_after_delete.status_code == 404, f"Пользователь {user['username']} не был удалён"
    logger.info(f"Тест удаления пользователя прошёл успешно: {user['username']}")

@pytest.mark.smoke
def test_toggle_settings(user):
    get_resp = user["api"].toggle_settings()

@pytest.mark.smoke
def test_toggle_group():
    return