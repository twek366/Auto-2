import pytest

from WS.helpers.dealers import (
    assert_dealer_response,
    update_dealer,
)
from WS.logging_config import logger


@pytest.mark.smoke
def test_create_dealer(dealer):
    logger.info(f"Тест создания дилера прошёл успешно: {dealer['name']}")

@pytest.mark.smoke
def test_update_dealer(dealer):
    resp, new_name = update_dealer(dealer["api"], dealer["id"])
    assert resp.status_code == 200
    assert resp.json()["name"] == new_name
    logger.info(f"Дилер {dealer['name']} ({dealer['id']}) успешно обновлён на {new_name}")

@pytest.mark.smoke
def test_get_dealer(dealer):
    get_resp = dealer["api"].get_by_id(dealer["id"])
    assert_dealer_response(get_resp, dealer["name"])
    logger.info(f"Тест получения дилера прошёл успешно: {dealer['name']}")

@pytest.mark.smoke
def test_delete_dealer(dealer):
    delete_resp = dealer["api"].delete_by_id(dealer["id"])
    assert delete_resp.status_code == 204, f"Не удалось удалить дилера {dealer['name']}: {delete_resp.status_code}"
    get_after_delete = dealer["api"].get_by_id(dealer["id"])
    assert get_after_delete.status_code == 404, f"Дилер {dealer['name']} не был удалён"
    logger.info(f"Тест удаления дилера прошёл успешно: {dealer['name']}")