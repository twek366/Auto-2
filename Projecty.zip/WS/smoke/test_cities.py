import pytest

from WS.helpers.cities import assert_city_response, update_city
from WS.logging_config import logger


@pytest.mark.smoke
def test_create_city(city):
    logger.info(f"Тест создания города прошёл успешно: {city['name']}")

@pytest.mark.smoke
def test_update_city(city):
    resp, new_name = update_city(city["api"], city["id"])

    assert resp.status_code == 200
    assert resp.json()["name"] == new_name

    logger.info(f"Город {city['name']} ({city['id']}) успешно обновлён на {new_name}")

@pytest.mark.smoke
def test_get_city(city):
    get_resp = city["api"].get_by_id(city["id"])
    assert_city_response(get_resp, city["name"])
    logger.info(f"Тест получения города прошёл успешно: {city['name']}")

@pytest.mark.smoke
def test_delete_city(city):
    delete_resp = city["api"].delete_by_id(city["id"])
    assert delete_resp.status_code == 204, f"Не удалось удалить город {city['name']}: {delete_resp.status_code}"

    get_after_delete = city["api"].get_by_id(city["id"])
    assert get_after_delete.status_code == 404, f"Город {city['name']} не был удалён"
    logger.info(f"Тест удаления города прошёл успешно: {city['name']}")
