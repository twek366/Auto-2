import pytest

from WS.api.cities_api import CitiesApi
from WS.helpers.cities import (
    assert_city_response,
    create_city_payload,
    generate_unique_city_name,
)
from WS.logging_config import logger


@pytest.fixture
def city(admin_token):
    api = CitiesApi(token=admin_token)
    name = generate_unique_city_name()
    payload = create_city_payload(name)

    data = None
    create_resp = api.create(payload)

    try:
        data = assert_city_response(create_resp, name)
        yield {"id": data["id"], "name": name, "api": api}
    finally:
        if data:
            delete_resp = api.delete_by_id(data["id"])
            logger.info(f"City delete status={delete_resp.status_code}")
