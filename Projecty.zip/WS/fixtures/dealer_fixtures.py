import pytest

from WS.api.dealers_api import DealersApi
from WS.helpers.dealers import (
    assert_dealer_response,
    create_dealer_payload,
    generate_unique_dealer_name,
)
from WS.logging_config import logger


@pytest.fixture
def dealer(admin_token):
    api = DealersApi(token=admin_token)
    name = generate_unique_dealer_name()
    payload = create_dealer_payload(name)
    create_resp = api.create(payload)
    data = assert_dealer_response(create_resp, name)
    yield {"id": data["id"], "name": name, "api": api}

    delete_resp = api.delete_by_id(data["id"])
    if delete_resp.status_code == 204:
        logger.info(f"Дилер {name} ({data['id']}) успешно удалён в teardown")
    else:
        logger.warning(f"Не удалось удалить дилера {name} ({data['id']}) в teardown: {delete_resp.status_code}")