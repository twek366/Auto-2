import pytest

from WS.api.auth_api import AuthApi
from WS.api.users_api import UsersApi
from WS.helpers.users import assert_user_auth_response, create_user_payload
from WS.logging_config import logger


@pytest.fixture
def user(admin_token, city):
    auth_client = AuthApi(token=admin_token)
    payload = create_user_payload(default_city=city["id"])

    create_resp = auth_client.register(payload)
    user_dto = assert_user_auth_response(create_resp)

    users_client = UsersApi(token=admin_token)

    yield {
        "id": user_dto.id,
        "email": user_dto.email,
        "username": user_dto.username,
        "register_client": auth_client,
        "api": users_client,
        "dto": user_dto,
    }

    delete_resp = users_client.delete_by_id(user_dto.id)
    if delete_resp.status_code == 204:
        logger.info(f"User {user_dto.email} ({user_dto.id}) deleted in teardown")
    else:
        logger.warning(f"Failed to delete user {user_dto.email} ({user_dto.id}): {delete_resp.status_code}")
