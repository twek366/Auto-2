import os

from dotenv import load_dotenv

load_dotenv()


base_url = os.getenv("base_url")
login_owner = os.getenv("login_owner")
pass_owner = os.getenv("pass_owner")
timeout = float(os.getenv("timeout", "10"))


if not all([base_url, login_owner, pass_owner]):
    raise ValueError("Не все обязательные переменные окружения заданы в .env файле!")

print(f"Подключение к: {base_url}")
print(f"Timeout: {timeout} сек")