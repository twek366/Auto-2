import pytest

from WS.api.base_client import BaseApiClient
from WS.fixtures.auth_fixtures import *
from WS.fixtures.city_fixtures import *
from WS.fixtures.dealer_fixtures import *
from WS.fixtures.user_fixtures import *
from WS.logging_config import logger


@pytest.fixture
def api_client(admin_token):
    return BaseApiClient(token=admin_token)

@pytest.fixture(autouse=True)
def log_test_start_end(request):
    logger.info(f"===== START TEST: {request.node.name} =====")
    yield
    logger.info(f"===== END TEST: {request.node.name} =====")