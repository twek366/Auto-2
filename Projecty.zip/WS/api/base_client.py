from pathlib import Path

import httpx

from WS.config.settings import base_url, timeout
from WS.logging_config import logger


class BaseApiClient:
    def __init__(self, token: str | None = None):
        self.base_url = base_url
        self._client = httpx.Client(base_url=self.base_url, timeout=timeout)
        self._token = token

    def _headers(self):
        headers = {"Content-Type": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    def _log_request_response(self, response: httpx.Response):
        req = response.request
        logger.info(f">>> {req.method} {req.url}")
        logger.debug(f">>> Headers: {req.headers}")
        if req.content:
            try:
                logger.debug(f">>> Body: {req.content.decode()}")
            except Exception:
                logger.debug(f">>> Body (binary): {req.content}")

        logger.info(f"<<< Status: {response.status_code}")
        logger.debug(f"<<< Response body: {response.text}")

    def get(self, path: str, params: dict | None = None):
        response = self._client.get(path, headers=self._headers(), params=params)
        self._log_request_response(response)
        return response

    def post(self, path: str, json: dict | None = None):
        response = self._client.post(path, headers=self._headers(), json=json)
        self._log_request_response(response)
        return response

    def put(self, path: str, json: dict | None = None):
        response = self._client.put(path, headers=self._headers(), json=json)
        self._log_request_response(response)
        return response

    def delete(self, path: str):
        response = self._client.delete(path, headers=self._headers())
        self._log_request_response(response)
        return response

    def post_file(
            self,
            endpoint: str,
            file_field: str,
            file_path: str | Path,
            content_type: str = "image/jpeg",
            extra_fields: dict | None = None,
    ) -> httpx.Response:
        file_path = Path(file_path)

        with file_path.open("rb") as file:
            files = {
                file_field: (
                    file_path.name,
                    file,
                    content_type,
                )
            }

            return self._client.post(
                f"{self.base_url}{endpoint}",
                files=files,
                data=extra_fields or {},
            )