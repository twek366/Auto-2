from WS.api.base_client import BaseApiClient


class AuthApi(BaseApiClient):
    def login(self, login: str, password: str):
        return self.post("/api/auth/login", json={"login": login, "password": password})

    def refresh(self):
        return self.get("/api/auth/refresh-token")

    def register(self, payload: dict):
        return self.post("/api/auth/register", json=payload)

    def roles(self):
        return self.get("/api/auth/roles")