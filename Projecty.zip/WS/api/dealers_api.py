from WS.api.base_client import BaseApiClient


class DealersApi(BaseApiClient):
    def list(self):
        return self.get("/api/dealers")

    def create(self, payload: dict):
        return self.post("/api/dealers", json=payload)

    def get_by_id(self, dealer_id: int):
        return self.get(f"/api/dealers/{dealer_id}")

    def update(self, dealer_id: int, payload: dict):
        return self.put(f"/api/dealers/{dealer_id}", json=payload)

    def delete_by_id(self, dealer_id: int):
        return self.delete(f"/api/dealers/{dealer_id}")