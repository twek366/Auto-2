from WS.api.base_client import BaseApiClient


class CitiesApi(BaseApiClient):
    def list(self):
        return self.get("/api/cities")

    def create(self, payload: dict):
        return self.post("/api/cities", json=payload)

    def get_by_id(self, city_id: int):
        return self.get(f"/api/cities/{city_id}")

    def update(self, city_id: int, payload: dict):
        return self.put(f"/api/cities/{city_id}", json=payload)

    def delete_by_id(self, city_id: int):
        return self.delete(f"/api/cities/{city_id}")