from WS.api.base_client import BaseApiClient


class ClientsApi(BaseApiClient):
    def list(self):
        return self.get("/api/clients")

    def create(self, payload: dict):
        return self.post("/api/clients", json=payload)

    def get_by_id(self, client_id: int):
        return self.get(f"/api/clients/{client_id}")

    def update(self, client_id: int, payload: dict):
        return self.put(f"/api/clients/{client_id}", json=payload)

    def delete_by_id(self, client_id: int):
        return self.delete(f"/api/clients/{client_id}")
