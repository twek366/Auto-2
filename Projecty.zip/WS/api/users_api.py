from WS.api.base_client import BaseApiClient


class UsersApi(BaseApiClient):
    #CRUD
    def list(self):
        return self.get("/api/users")

    def create(self, payload: dict):
        return self.post("/api/users", json=payload)

    def get_by_id(self, user_id: int):
        return self.get(f"/api/users/{user_id}")

    def update(self, user_id: int, payload: dict):
        return self.put(f"/api/users/{user_id}", json=payload)

    def delete_by_id(self, user_id: int):
        return self.delete(f"/api/users/{user_id}")

    #User settings/groups
    def toggle_group(self, user_id: int, group_id: int):
        return self.put(f"/api/users/{user_id}/groups/{group_id}")

    def toggle_settings(self, user_id: int, setting_id: int):
        return self.put(f"/api/users/{user_id}/settings/{setting_id}")

    #Profile
    def get_profile(self):
        return self.get("api/users/profile")

    def upload_avatar(self, user_id: int, file_path: str):
        return self.post_file(
            endpoint=f"/users/{user_id}/avatar",
            file_field="avatar",
            file_path=file_path,
            content_type="image/png",
        )